// api/generate.js — Vercel Serverless Function (CommonJS)
const https = require('https');

module.exports = async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 허용됩니다' });

  const { diary, pov, tone, parentName, childName } = req.body || {};

  if (!diary || diary.trim().length < 5) {
    return res.status(400).json({ error: '일기 내용이 너무 짧습니다' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY 환경변수가 없습니다. Vercel 대시보드 → Settings → Environment Variables에서 추가해주세요.' });
  }

  const parent = parentName || '엄마';
  const child  = childName  || '아이';
  const povStr = pov === 'child'
    ? `${child}가 어른이 되어 회상하는 1인칭 시점`
    : `카메라가 바라보는 3인칭 내레이션 시점`;

  const systemPrompt = `너는 부모의 육아일기를 분석해서 AI 영상 생성용 프롬프트를 만드는 전문가다.
반드시 아래 JSON 형식으로만 응답해라. 마크다운, 설명, 코드블록 없이 순수 JSON만 출력해라.
{
  "keywords": ["감정 키워드1", "키워드2", "키워드3", "키워드4"],
  "analysis": "상황 분석 2~3문장",
  "narration": "${povStr}로 쓴 3~4문장 내레이션. 이모지 따옴표 없이 자연스러운 발화 텍스트로.",
  "prompt": "HeyGen Runway Kling 같은 영상 생성 도구에 바로 붙여넣을 수 있는 영문 프롬프트. 톤: ${tone || 'soft watercolor animation'}. ${parent}를 주인공으로. 카메라 움직임 조명 분위기 포함. 60초 분량."
}`;

  const body = JSON.stringify({
    model: 'claude-sonnet-4-6',
    max_tokens: 800,
    system: systemPrompt,
    messages: [{ role: 'user', content: `일기 내용:\n${diary.trim()}` }],
  });

  try {
    const result = await new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Length': Buffer.byteLength(body),
        },
      };

      const request = https.request(options, (response) => {
        let data = '';
        response.on('data', chunk => data += chunk);
        response.on('end', () => resolve({ status: response.statusCode, body: data }));
      });

      request.on('error', reject);
      request.write(body);
      request.end();
    });

    if (result.status !== 200) {
      return res.status(502).json({ error: `Claude API 오류 (${result.status})`, detail: result.body });
    }

    const data = JSON.parse(result.body);
    const raw = (data.content || []).map(b => b.text || '').join('\n').trim();
    const cleaned = raw
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/```\s*$/i, '')
      .trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return res.status(502).json({ error: '응답 파싱 실패', raw: cleaned });
    }

    return res.status(200).json(parsed);
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
};
